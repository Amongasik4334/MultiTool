#include "kernel.h"
#include "console.h"
#include "string.h"
#include "gdt.h"
#include "idt.h"
#include "keyboard.h"
#include "io_ports.h"
#include "multiboot.h"

#define BRAND_QEMU  1
#define BRAND_VBOX  2

void BSOD(char* reason)
{
    vga_disable_cursor();
    console_clear(COLOR_WHITE, COLOR_BLACK);

    console_color(COLOR_RED, COLOR_BLACK);
    printf("ERROR:\n");

    console_color(COLOR_WHITE, COLOR_BLACK);
    printf("  %s", reason);

    while(1) {}
}

void __cpuid(uint32 type, uint32 *eax, uint32 *ebx, uint32 *ecx, uint32 *edx) {
    asm volatile("cpuid"
                : "=a"(*eax), "=b"(*ebx), "=c"(*ecx), "=d"(*edx)
                : "0"(type)); // put the type into eax
}

int cpuid_info(int print) {
    uint32 brand[12];
    uint32 eax, ebx, ecx, edx;
    //uint32 type;

    memset(brand, 0, sizeof(brand));
    __cpuid(0x80000002, (uint32 *)brand+0x0, (uint32 *)brand+0x1, (uint32 *)brand+0x2, (uint32 *)brand+0x3);
    __cpuid(0x80000003, (uint32 *)brand+0x4, (uint32 *)brand+0x5, (uint32 *)brand+0x6, (uint32 *)brand+0x7);
    __cpuid(0x80000004, (uint32 *)brand+0x8, (uint32 *)brand+0x9, (uint32 *)brand+0xa, (uint32 *)brand+0xb);

    if (print) {
        printf("Brand: %s\n", brand);
        // for(type = 0; type < 4; type++) {
        //     __cpuid(type, &eax, &ebx, &ecx, &edx);
        //     printf("type:0x%x, eax:0x%x, ebx:0x%x, ecx:0x%x, edx:0x%x\n", type, eax, ebx, ecx, edx);
        // }
    }

    if (strstr(brand, "QEMU") != NULL)
        return BRAND_QEMU;

    return BRAND_VBOX;
}

void mem_info(unsigned long magic, unsigned long addr) {
    MULTIBOOT_INFO *mboot_info;
    uint32 i;

    console_clear(COLOR_WHITE, COLOR_BLACK);
    //printf("magic: 0x%x\n", magic);
    if(magic == MULTIBOOT_BOOTLOADER_MAGIC) {
        mboot_info = (MULTIBOOT_INFO *)addr;
        printf("Boot loader: %s\n", (char *)mboot_info->boot_loader_name);
        printf("Boot device: 0x%x\n", mboot_info->boot_device);
        //printf("  flags: 0x%x\n", mboot_info->flags);
        printf("mem_low: 0x%x KB\n", mboot_info->mem_low);
        printf("mem_high: 0x%x KB\n", mboot_info->mem_high);
        //printf("  cmdline: %s\n", (char *)mboot_info->cmdline);
        printf("modules_count: %d\n", mboot_info->modules_count);
        printf("modules_addr: 0x%x\n", mboot_info->modules_addr);
        printf("mmap_length: %d\n", mboot_info->mmap_length);
        printf("mmap_addr: 0x%x\n", mboot_info->mmap_addr);
        printf("memory map:-\n");
        for (i = 0; i < mboot_info->mmap_length; i += sizeof(MULTIBOOT_MEMORY_MAP)) {
            MULTIBOOT_MEMORY_MAP *mmap = (MULTIBOOT_MEMORY_MAP *)(mboot_info->mmap_addr + i);
            printf("    size: %d, addr: 0x%x%x, len: %d%d, type: %d\n", 
                    mmap->size, mmap->addr_low, mmap->addr_high, mmap->len_low, mmap->len_high, mmap->type);
            if (mmap->type == MULTIBOOT_MEMORY_AVAILABLE) {
                /**** Available memory  ****/
            }
        }
        printf("vbe_control_info: 0x%x\n", mboot_info->vbe_control_info);
        printf("vbe_mode_info: 0x%x\n", mboot_info->vbe_mode_info);
        printf("framebuffer_addr: 0x%x\n", mboot_info->framebuffer_addr);
        printf("framebuffer_width: %d\n", mboot_info->framebuffer_width);
        printf("framebuffer_height: %d\n", mboot_info->framebuffer_height);
        printf("framebuffer_type: %d\n", mboot_info->framebuffer_type);
    } else {
        printf("invalid multiboot magic number\n");
    }
}

BOOL is_echo(char *b) {
    if((b[0]=='e')&&(b[1]=='c')&&(b[2]=='h')&&(b[3]=='o'))
        if(b[4]==' '||b[4]=='\0')
            return TRUE;
    return FALSE;
}

void shutdown() {
    int brand = cpuid_info(0);
    // QEMU
    if (brand == BRAND_QEMU)
        outports(0x604, 0x2000);
    else
        // VirtualBox
        outports(0x4004, 0x3400);
}

void kmain(unsigned long magic, unsigned long addr) {
    char buffer[255];
    const char *shell = "-amr>";

    gdt_init();
    idt_init();

    console_init(COLOR_WHITE, COLOR_BLACK);
    keyboard_init();

    console_clear(COLOR_WHITE, COLOR_BLACK);
    printf("AMare Terminal v6.0.0\nCommander AMare (C) 2023-2025\n\n");
    //mem_info(magic, addr);

    while(1) {
        console_color(COLOR_RED, COLOR_BLACK);
        printf("root");
        console_color(COLOR_WHITE, COLOR_BLACK);
        printf(shell);

        memset(buffer, 0, sizeof(buffer));
        read_line(buffer, strlen(shell));

        if (strlen(buffer) == 0)
            continue;

        //info commands
        if(strcmp(buffer, "cpuid") == 0) {
            cpuid_info(1);
        }
        else if(strcmp(buffer, "meminfo") == 0) {
            mem_info(magic, addr);
        }
        else if(strcmp(buffer, "help") == 0) {
            printf("========Help========\nhelp\ncpuid\nmeminfo\nbsod\ntitle\nclear\necho\nshutdown\n====================\n");
        }
        else if(strcmp(buffer, "bsod") == 0) {
            BSOD("this fake bsod\n");
        }
        else if(strcmp(buffer, "clear") == 0) {
            console_clear(COLOR_WHITE, COLOR_BLACK); printf("%c", '\n');
        }
        else if(strcmp(buffer, "title") == 0) {
            printf("AMare Terminal v6.0.0\nCommander AMare (C) 2023-2025\n\n");
        }

        else if(is_echo(buffer)) {
            printf("%s\n", buffer + 5);
        } else if(strcmp(buffer, "shutdown") == 0) {
            shutdown();
        } else {
            printf("invalid command:%s\n", buffer);
        }
    }
}



